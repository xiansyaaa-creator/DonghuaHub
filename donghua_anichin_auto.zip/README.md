# DonghuaHub — Auto Update

Project katalog donghua dengan data episode dari halaman publik sumber.

## Auto update

Workflow `.github/workflows/auto-update.yml` menjalankan scraper otomatis setiap 6 jam dan juga bisa dijalankan manual dari GitHub Actions.

Alurnya:

`GitHub Actions → scrape episode baru → update JSON → commit → push → Vercel auto deploy`

Tidak perlu menjalankan Pydroid terus-menerus.

## Deploy

1. Upload project ini ke repository GitHub.
2. Import repository tersebut ke Vercel.
3. Setelah itu, setiap perubahan JSON yang di-push oleh GitHub Actions akan memicu deployment Vercel jika repository Vercel terhubung.

## Catatan

Scraper hanya mengambil metadata/URL halaman episode publik. Project tidak mengunduh atau me-host video.
