#!/usr/bin/env python3
"""Auto-updater metadata episode publik.

- Maksimum episode yang pernah dicek: 1000 per judul.
- Jika JSON sudah ada, hanya mengecek setelah episode tertinggi yang tersimpan.
- Berhenti setelah beberapa 404 berturut-turut agar update berkala ringan.
- Tidak mengunduh atau me-host video.
"""
import json
import os
import re
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "public", "data")
os.makedirs(DATA_DIR, exist_ok=True)

MAX_EPISODE = 1000
CONSECUTIVE_404_LIMIT = 8
DELAY = 0.5
TIMEOUT = 15

ANIME = [
    {"id":"renegade-immortal","title":"Renegade Immortal","slug":"renegade-immortal-episode-{}-subtitle-indonesia","source":"https://anichin.moe","max_known":159},
    {"id":"battle-through-the-heavens-season-5","title":"Battle Through the Heavens — Season 5","slug":"btth-season-5-episode-{}-subtitle-indonesia","source":"https://anichin.moe","max_known":212},
    {"id":"beyond-times-gaze","title":"Beyond Time's Gaze","slug":"beyond-times-gaze-episode-{}-subtitle-indonesia","source":"https://anichin.moe","max_known":41},
    {"id":"supreme-god-emperor","title":"Supreme God Emperor","slug":"supreme-god-emperor-episode-{}-subtitle-indonesia","source":"https://anichin.moe","max_known":643},
]

UA = "Mozilla/5.0 (compatible; DonghuaCatalog/1.0)"

def episode_url(anime, n):
    return f"{anime['source']}/{anime['slug'].format(n)}/"

def check_episode(anime, n):
    url = episode_url(anime, n)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            html = r.read().decode("utf-8", "ignore")
        low = re.sub(r"\s+", " ", html.lower())
        if anime["id"] == "battle-through-the-heavens-season-5":
            ok = "btth season 5" in low or "battle through the heavens" in low
        else:
            ok = anime["title"].split("—")[0].strip().lower() in low
        if not ok:
            return None, "invalid"
        m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
        page_title = re.sub(r"\s+", " ", m.group(1)).strip() if m else f"{anime['title']} Episode {n}"
        return {"episode": n, "title": page_title, "url": url}, "ok"
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None, "404"
        return None, "error"
    except Exception:
        return None, "error"

def load_existing(path):
    if not os.path.exists(path):
        return {"episodes": []}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"episodes": []}

def scrape(anime):
    path = os.path.join(DATA_DIR, anime["id"] + ".json")
    old = load_existing(path)
    by_ep = {int(x["episode"]): x for x in old.get("episodes", []) if "episode" in x}
    highest = max(by_ep, default=0)
    # First run starts at 1; later runs continue after current highest.
    start = highest + 1 if highest else 1
    # Never start above the hard ceiling.
    if start > MAX_EPISODE:
        print(f"[{anime['title']}] sudah mencapai batas {MAX_EPISODE}.")
        return

    print(f"\n=== {anime['title']} ===")
    print(f"Mengecek episode {start} sampai {MAX_EPISODE}...")
    misses = 0
    for n in range(start, MAX_EPISODE + 1):
        item, status = check_episode(anime, n)
        if item:
            by_ep[n] = item
            misses = 0
            print(f"[OK] Episode {n}")
        elif status == "404" or status == "invalid":
            misses += 1
            print(f"[--] Episode {n} belum tersedia")
            if misses >= CONSECUTIVE_404_LIMIT:
                print(f"Berhenti setelah {misses} episode berturut-turut tidak ditemukan.")
                break
        else:
            print(f"[!] Episode {n}: koneksi/error, dilewati untuk run ini")
        time.sleep(DELAY)

    episodes = [by_ep[n] for n in sorted(by_ep)]
    payload = {
        "id": anime["id"],
        "title": anime["title"],
        "source": anime["source"],
        "checked_to": MAX_EPISODE,
        "total_episodes_found": len(episodes),
        "highest_episode": max(by_ep, default=0),
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "episodes": episodes,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"Saved: {path} | total={len(episodes)} | highest={payload['highest_episode']}")

def main():
    print("DonghuaHub auto-updater")
    for anime in ANIME:
        scrape(anime)
    catalog = [{"id":a["id"],"title":a["title"]} for a in ANIME]
    with open(os.path.join(DATA_DIR, "catalog.json"), "w", encoding="utf-8") as f:
        json.dump(catalog, f, ensure_ascii=False, indent=2)
    print("\nDONE")

if __name__ == "__main__":
    main()
